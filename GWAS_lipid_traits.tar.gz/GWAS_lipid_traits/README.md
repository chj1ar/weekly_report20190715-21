# Documentation of directories and files

## `HDL/`

This directory stores the original HDL GWAS data, which is [this zip](http://csg.sph.umich.edu/willer/public/lipids2010/HDL2010.zip) stored in [this website](http://csg.sph.umich.edu/willer/public/lipids2010/). You can similarly download the others, namely, LDL, TG and TC. Before running Enloc, you should unzip it to generate the HDL GWAS data.

## `HDL_zscore/`

This directory is for output of GWAS data for Torus. Please find the details in `../code/Enloc`. The file `tmp_HDL.zscore` is just for confirmation.

## `bed_Whole_Blood_v7_egenes_annotations`

This directory contains annotation data. For now we only use `ld_chunk.bed`. Please find the details in `../code/Enloc`.

## `SNPtable.csv`

This file is not here since it is too large, but this file is necessary for running the scripts in `../code/Enloc`. Specifically, it is used to map rsID in the original lipid GWAS files to ChrPos. It contains only autosomal chromosomes since we will only run on autosomal chromosomes. You can obtain it by running the following command.
```
wget -c -t 0 ftp://ftp.ncbi.nlm.nih.gov/snp/organisms/human_9606_b151_GRCh37p13/VCF/common_all_20180423.vcf.gz # note that the vcf file is 1.5GB
zgrep -v '^##' common_all_20180423.vcf.gz | cut -f 1-3 | grep -v '[XY]' | sed '1d' > SNPtable.csv
```
